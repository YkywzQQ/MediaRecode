[app]
version=1.0
file=http://localhost/media-recode/api/updater/app.zip

[core]
version=2.5.6
file=http://localhost/media-recode/api/updater/core.zip
